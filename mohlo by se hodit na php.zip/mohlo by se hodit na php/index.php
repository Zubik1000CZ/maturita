<!doctype html>
<html lang="cs">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>O Zubíkovi</title>
    <meta name="description" content="Vše o Zubíkovi.">
    <meta property="og:title" content="O Zubíkovi">
    <meta property="og:type" content="web">
    <meta property="og:url" content="">
    <meta property="og:description" content="Vše o Zubíkovi, projekty, kontakt...">
    <link rel="icon" type="image/x-icon" href="./assets/Icon.ico">
    <link rel="apple-touch-icon" href="./assets/Icon.png">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <div class="Toplogo">

        <video autoplay loop muted plays-inline class="back-video">
            <source src="./assets/BackgV1D.mp4" type="video/mp4">
        </video>
        <!--poznamka-->
        <nav id="nav" class="desktop">
        <ul>
                <li><a href="index.php">Domů</a></li>
                <li><a href="index.php#read">O mně</a></li>
                <li><a href="index.php#github">GitHub</a></li>
                <li><a href="3Dmodels.php">3D modely</a></li>
                <li><a href="games.php">Hry</a></li>
                <li><a href="YouTube.php">YouTube</a></li>
                <li><a href="MyPC.php">Můj PC</a></li>
            </ul>
            <img class="IconDesktop" src="./assets/Icon.ico" alt="Icon">
        </nav>
        <nav class="mobile" role="navigation">
            <div id="mobilehamburger">
                <input type="checkbox" />
                <span></span>
                <span></span>
                <span></span>
                <ul id="menu">
                  <a href="index.php"><li>Domů</li></a>
                  <a href="index.php#read"><li>O mně</li></a>
                  <a href="index.php#github"><li>GitHub</li></a>
                  <a href="3Dmodels.php"><li>3D modely</li></a>
                  <a href="games.php"><li>Hry</li></a>
                  <a href="YouTube.php"><li>YouTube</li></a>
                  <a href="MyPC.php"><li>Můj PC</li></a>
                </ul>
              </div>
              <img class="Icon" src="./assets/Icon.ico" alt="Icon">
        </nav>
        
        <div class="content">
            <h1 style="font-size:10vw" >Zubik1000CZ</h1>
            <h2 style="font-size:5vw; color:red;">Znalec PC Hardwaru</h2>
            <a href="#read" >Číst</a>
        </div>
        <br>
        <div class="overlay">
            <br id="read">
            <br>
            <div class="article">
                <div class="text">
                    Přidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2023-01-13";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br>
                    <h3>Jmenuji se Michal Zoufalý, ale převážně vystupuji pod přezdívkou Zubik1000CZ</h3>
                    <h3>Je mi 19 let a jsem studentem Informačních technologií na <a href="https://www.vos-sps-jicin.cz/?main=aktuality" target="_blank" class="link">Vyšší odborné a Střední průmyslové škole v Jičíně</a> </h3>
                    <br>
                    <h3>Jsem začínající game developer a 3D modelář</h3>
                    <h3>Mými koníčky jsou tvorba a hraní počítačových her, vytváření 3D modelů a tvorba stránek jako je třeba tato</h3>
                    <br>
                    <h3>Také se již 6 let věnuji počítačům. Rád stavím počítače a pořád čtu novinky o hardwaru. Vím toho o hardwaru docela hodně. A přeci málo :D.</h3>
                    
                </div>
            </div>
            <br>
            <br>
            
            <div class="article">
                <br>
                <h1>YouTube</h1>
                <div class="text">
                    <h3>Na YouTube jsem točil ještě na základní škole.</h3><br>
                    <h3>Původně se však jednalo o videa z hry World of Tanks. Od roku 2023 se však věnuji tvorbě obsahu o počítačích.</h3><br>
                    <h3>Na mém <a href="https://www.youtube.com/@Zubik1000CZ" target="_blank" class="link">kanále</a> můžete najít různé návody, vysvětlování apod. </h3><br>
                    <h3>Občas tam můžete najít aj nějaká porovnání různých počítačových sestav.</h3>
                    
                </div>
            </div>
            <br id="github">
            <br>
            <div class="article">
                <br>
                <h1>GitHub</h1>
                <div class="text">
                    <h3>Mám vlastní GitHub, kam nahrávám své vlastní výtvory.</h3>
                    <h3>Na Githubu mě lze nalézt pod přezdívkou Zubik1000CZ, nebo <a href="https://github.com/Zubik1000CZ" target="_blank" class="link">zde</a>.</h3>
                    <br>
                    <h3>Případně můžeš použít jednu z těchto zkratek:</h3>
                    <h3><a href="https://github.com/Zubik1000CZ/Unity-by-Zubik1000CZ" target="_blank" class="link">Hry</a> ke stažení. <a href="games.html" target="_blank" class="link">Zde</a> si je můžeš prohlédnout.</h3>
                    <h3><a href="https://github.com/Zubik1000CZ/3D-models" target="_blank" class="link">3D modely</a> ke stažení. <a href="3Dmodels.html" target="_blank" class="link">Zde</a> si je můžeš prohlédnout.</h3>
                </div>
            </div>

            <br>
            <!--?php  $date = date('d-m-Y h:i'); echo("$date");?-->
            
            <footer class="footer">
                <p id="left"> email: michalzoufaly14@gmail.com</p>
                <p id="center"> &copyZubik1000CZ   2022-<?php echo date("Y");?></p>
                <p id="right"> Discord: Zubik1000CZ#7909</p>
        </footer>
        </div>
    </div>
</body>
</html>