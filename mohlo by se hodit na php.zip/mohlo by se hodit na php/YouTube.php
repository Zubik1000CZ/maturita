
<!doctype html>
<html lang="cs">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Youtube</title>
    <meta name="description" content="Vše o Zubíkovi.">
    <meta property="og:title" content="O Zubíkovi">
    <meta property="og:type" content="web">
    <meta property="og:url" content="">
    <meta property="og:description" content="Vše o Zubíkovi, projekty, kontakt...">
    <link rel="icon" type="image/x-icon" href="./assets/Icon.ico">
    <link rel="apple-touch-icon" href="./assets/Icon.png">
    <link rel="stylesheet" href="styles.css">

</head>

<body>
    <script src="scripts.js"></script>
    <div class="Toplogo">

        <video autoplay loop muted plays-inline class="back-video">
            <source src="./assets/BackgV1D.mp4" type="video/mp4">
        </video>
        <!--poznamka-->
        <nav id="nav" class="desktop">
        <ul>
                <li><a href="index.php">Domů</a></li>
                <li><a href="index.php#read">O mně</a></li>
                <li><a href="index.php#github">GitHub</a></li>
                <li><a href="3Dmodels.php">3D modely</a></li>
                <li><a href="games.php">Hry</a></li>
                <li><a href="YouTube.php">YouTube</a></li>
                <li><a href="MyPC.php">Můj PC</a></li>
            </ul>
            <img class="IconDesktop" src="./assets/Icon.ico" alt="Icon">
        </nav>
        <nav class="mobile" role="navigation">
            <div id="mobilehamburger">
                <input type="checkbox" />
                <span></span>
                <span></span>
                <span></span>
                <ul id="menu">
                  <a href="index.php"><li>Domů</li></a>
                  <a href="index.php#read"><li>O mně</li></a>
                  <a href="index.php#github"><li>GitHub</li></a>
                  <a href="3Dmodels.php"><li>3D modely</li></a>
                  <a href="games.php"><li>Hry</li></a>
                  <a href="YouTube.php"><li>YouTube</li></a>
                  <a href="MyPC.php"><li>Můj PC</li></a>
                </ul>
              </div>
              <img class="Icon" src="./assets/Icon.ico" alt="Icon">
        </nav>
        <div class="content">
            <h1 style="font-size:10vw" >YouTube</h1>
            <a href="#read">Číst</a>
        </div>
        <br>
        <div class="overlay">
            <br id="read">
            <br>
            <div class="article">
                <div class="text">
                    <h3>V této záložce, která se tu objevila ani nevím jak, můžeš narazit na videa, která jsem nahrál na YouTube..</h3>
                    <br>
                    <h3 style="color :red;">Proč jsem se rozhodl točit?</h3>
                    <h3> Protože mě počítače baví a i přesto, že vím docela hodně, pořád nevím dost.</h3>
                    <h3> A toto mi pomáhá rozšiřovat znalosti a ty pak šířím dál  :).</h3>
                    <br>
                    <h3>Můj kanál můžeš najít <a href="https://www.youtube.com/@Zubik1000CZ" target="_blank" class="link">zde</a>.</h3>
                </div>
            </div>
            <br>
            
            <div class="YTContback">
                <br>
            Přidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2023-02-18";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br><br>

                    <!--<?php
                        $file = fopen("file.txt", "r") or die("Unable to open file!");
                        echo fread($file,filesize("file.txt"));
                        fclose($file);
                    ?>
                    <br>
                    <?php
                        $file = fopen("newfile.txt", "w") or die("Unable to open file!");
                        $txt = "John Doe\n";
                        fwrite($file, $txt);
                        fclose($file);
                    ?>  
                    <?php
                        $file = fopen("newfile.txt", "r") or die("Unable to open file!");
                        echo fread($file,filesize("newfile.txt"));
                        fclose($file);
                    ?><br><br>-->

                <h1>Jak flashnout BIOS?</h1>
                <div class="YTcontainer">
                    <iframe class="YTVideo" src="https://www.youtube.com/embed/DjcWxDbNr8U"></iframe>
                </div>

                    <form method="GET">
                        <input type="submit" name="like4"    value="Paleček hore :D"> x <input type="submit" name="dislike4" value="Paleček dole :(("><br>
                    </form>
                    <br>
                    

                    <?php 
                        $servername = "localhost";
                        $username = "zubik1000cz";
                        $password = "qwertzuI9";
                        $database = "zubik1000cz";
                        $conn = mysqli_connect($servername, $username, $password, $database);
                        
                        if(!$conn){
                            die('Připojení selhalo: ' . mysqli_connect_error());
                        }
                        //Vytvoří tabulku
                        /*$sql="CREATE TABLE tabulka (
                            id INT(5) AUTO_INCREMENT PRIMARY KEY,
                            likes INT(30) NOT NULL
                            )";
                        mysqli_query($conn,$sql);*/

                        //$sql="INSERT INTO tabulka (likes) VALUES (1)";
                        //mysqli_query($conn,$sql);

                        $likeCount = 0;
                        $sql="SELECT likes FROM tabulka /*ORDER BY id DESC LIMIT 1*/ WHERE id=4";
                        $result=mysqli_query($conn,$sql);
                        $like=mysqli_fetch_assoc($result);
                        $likeCount = $like["likes"];

                        $dislikeCount = 0;
                        $sql="SELECT dislikes FROM tabulka /*ORDER BY id DESC LIMIT 1*/ WHERE id=4";
                        $result=mysqli_query($conn,$sql);
                        $like=mysqli_fetch_assoc($result);
                        $dislikeCount = $like["dislikes"];
                        
                        //přidá like
                        $nextLike = 1;
                        if (isset($_GET['like4']))
                        {
                            $likeCount = $likeCount + $nextLike;
                        }
                        echo ("počet Liků: ".$likeCount.'<br>');

                        //přidá dislike
                        $nextdisLike = 1;
                        if (isset($_GET['dislike4']))
                        {
                            $dislikeCount = $dislikeCount + $nextdisLike;
                        }
                         echo ("počet Disliků: ".$dislikeCount."    ");

                       /* $likefile = fopen("likefile.txt", "w") or die("Unable to open file!");
                        $txt = "1\n";
                        fwrite($likefile, $likeCount);
                        fclose($likefile);*/

                        //zapíše počet liků na server
                        if (isset($_GET['like4']))
                        {
                            /*$sql="DELETE FROM tabulka WHERE likes";
                            mysqli_query($conn,$sql);
                            $sql="INSERT INTO tabulka (likes) VALUES ('$likeCount')";*/
                            $sql="UPDATE tabulka SET likes='$likeCount' WHERE id=4";
                            mysqli_query($conn,$sql);
                        }

                        //zapíše počet disliků na server
                        if (isset($_GET['dislike4']))
                        {
                            $sql="UPDATE tabulka SET dislikes='$dislikeCount' WHERE id=4";
                            mysqli_query($conn,$sql);
                        }
                    ?>
                    <br><br>
                
            </div>

            <br>

            <div class="YTContback">
            <br>
            Přidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2023-02-11";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br><br>
                    
                <h1>Jak nainstalovat Windows by Zubík</h1>
                <div class="YTcontainer">
                    <iframe class="YTVideo" src="https://www.youtube.com/embed/A6L4zRRKtvQ"></iframe>
                </div>

                    <form method="GET">
                        <input type="submit" name="like3"    value="Paleček hore :D"> x <input type="submit" name="dislike3" value="Paleček dole :(("><br>
                    </form>
                    <br>

                    <?php 
                        $username = "zubik1000cz";
                        $password = "qwertzuI9";
                        $database = "zubik1000cz";
                        $conn = mysqli_connect($servername, $username, $password, $database);
                        
                        if(!$conn){
                            die('Připojení selhalo: ' . mysqli_connect_error());
                        }

                        $likeCount = 0;
                        $sql="SELECT likes FROM tabulka WHERE id=3";
                        $result=mysqli_query($conn,$sql);
                        $like=mysqli_fetch_assoc($result);
                        $likeCount = $like["likes"];

                        $dislikeCount = 0;
                        $sql="SELECT dislikes FROM tabulka WHERE id=3";
                        $result=mysqli_query($conn,$sql);
                        $like=mysqli_fetch_assoc($result);
                        $dislikeCount = $like["dislikes"];
                        
                        //přidá like
                        $nextLike = 1;
                        if (isset($_GET['like3']))
                        {
                            $likeCount = $likeCount + $nextLike;
                        }
                        echo ("počet Liků: ".$likeCount.'<br>');

                        //přidá dislike
                        $nextdisLike = 1;
                        if (isset($_GET['dislike3']))
                        {
                            $dislikeCount = $dislikeCount + $nextdisLike;
                        }
                         echo ("počet Disliků: ".$dislikeCount."    ");

                        //zapíše počet liků na server
                        if (isset($_GET['like3']))
                        {
                            $sql="UPDATE tabulka SET likes='$likeCount' WHERE id=3";
                            mysqli_query($conn,$sql);
                        }

                        //zapíše počet disliků na server
                        if (isset($_GET['dislike3']))
                        {
                            $sql="UPDATE tabulka SET dislikes='$dislikeCount' WHERE id=3";
                            mysqli_query($conn,$sql);
                        }
                    ?>
                    <br><br>
            </div>

            <br>

            <div class="YTContback">
            <br>
            Přidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2023-01-28";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br><br>
                    
                <h1>Stavíme PC se Zubíkem</h1>
                <div class="YTcontainer">
                    <iframe class="YTVideo" src="https://www.youtube.com/embed/csSMk-HVyY8"></iframe>
                </div>

                    <form method="GET">
                        <input type="submit" name="like2"    value="Paleček hore :D"> x <input type="submit" name="dislike2" value="Paleček dole :(("><br>
                    </form>
                    <br>

                    <?php 
                        $servername = "localhost";
                        $username = "zubik1000cz";
                        $password = "qwertzuI9";
                        $database = "zubik1000cz";
                        $conn = mysqli_connect($servername, $username, $password, $database);
                        
                        if(!$conn){
                            die('Připojení selhalo: ' . mysqli_connect_error());
                        }

                        $likeCount = 0;
                        $sql="SELECT likes FROM tabulka WHERE id=2";
                        $result=mysqli_query($conn,$sql);
                        $like=mysqli_fetch_assoc($result);
                        $likeCount = $like["likes"];

                        $dislikeCount = 0;
                        $sql="SELECT dislikes FROM tabulka WHERE id=2";
                        $result=mysqli_query($conn,$sql);
                        $like=mysqli_fetch_assoc($result);
                        $dislikeCount = $like["dislikes"];
                        
                        //přidá like
                        $nextLike = 1;
                        if (isset($_GET['like2']))
                        {
                            $likeCount = $likeCount + $nextLike;
                        }
                        echo ("počet Liků: ".$likeCount.'<br>');

                        //přidá dislike
                        $nextdisLike = 1;
                        if (isset($_GET['dislike2']))
                        {
                            $dislikeCount = $dislikeCount + $nextdisLike;
                        }
                         echo ("počet Disliků: ".$dislikeCount."    ");

                        //zapíše počet liků na server
                        if (isset($_GET['like2']))
                        {
                            $sql="UPDATE tabulka SET likes='$likeCount' WHERE id=2";
                            mysqli_query($conn,$sql);
                        }

                        //zapíše počet disliků na server
                        if (isset($_GET['dislike2']))
                        {
                            $sql="UPDATE tabulka SET dislikes='$dislikeCount' WHERE id=2";
                            mysqli_query($conn,$sql);
                        }
                    ?>
                    <br><br>
            </div>
            <br>

            <div class="YTContback">
            <br>
            pPřidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2023-01-20";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br><br>
                    
                <h1>Intel Core i3 4150 vs AMD Ryzen 5 7600</h1>
                <div class="YTcontainer">
                    <iframe class="YTVideo" src="https://www.youtube.com/embed/99zkAdpB6J0"></iframe>
                </div>

                    <form method="GET">
                        <input type="submit" name="like1"    value="Paleček hore :D"> x <input type="submit" name="dislike1" value="Paleček dole :(("><br>
                    </form>
                    <br>

                    <?php 
                        $servername = "localhost";
                        $username = "zubik1000cz";
                        $password = "qwertzuI9";
                        $database = "zubik1000cz";
                        $conn = mysqli_connect($servername, $username, $password, $database);
                        
                        if(!$conn){
                            die('Připojení selhalo: ' . mysqli_connect_error());
                        }

                        $likeCount = 0;
                        $sql="SELECT likes FROM tabulka WHERE id=1";
                        $result=mysqli_query($conn,$sql);
                        $like=mysqli_fetch_assoc($result);
                        $likeCount = $like["likes"];

                        $dislikeCount = 0;
                        $sql="SELECT dislikes FROM tabulka WHERE id=1";
                        $result=mysqli_query($conn,$sql);
                        $like=mysqli_fetch_assoc($result);
                        $dislikeCount = $like["dislikes"];
                        
                        //přidá like
                        $nextLike = 1;
                        if (isset($_GET['like1']))
                        {
                            $likeCount = $likeCount + $nextLike;
                        }
                        echo ("počet Liků: ".$likeCount.'<br>');

                        //přidá dislike
                        $nextdisLike = 1;
                        if (isset($_GET['dislike1']))
                        {
                            $dislikeCount = $dislikeCount + $nextdisLike;
                        }
                         echo ("počet Disliků: ".$dislikeCount."    ");

                        //zapíše počet liků na server
                        if (isset($_GET['like1']))
                        {
                            $sql="UPDATE tabulka SET likes='$likeCount' WHERE id=1";
                            mysqli_query($conn,$sql);
                        }

                        //zapíše počet disliků na server
                        if (isset($_GET['dislike1']))
                        {
                            $sql="UPDATE tabulka SET dislikes='$dislikeCount' WHERE id=1";
                            mysqli_query($conn,$sql);
                        }
                    ?>
                    <br><br>
            </div>
            
            <br>
           
           <br>
           <footer class="footer">
            <p id="left"> email: michalzoufaly14@gmail.com</p>
            <p id="center"> &copyZubik1000CZ   2022-<?php echo date("Y");?></p>
            <p id="right"> Discord: Zubik1000CZ#7909</p>
    </footer>
        </div>
    </div>
</body>
</html>