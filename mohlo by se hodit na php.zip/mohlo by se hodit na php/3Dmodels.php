<!doctype html>
<html lang="cs">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>3D modely</title>
    <meta name="description" content="Vše o Zubíkovi.">
    <meta property="og:title" content="O Zubíkovi">
    <meta property="og:type" content="web">
    <meta property="og:url" content="">
    <meta property="og:description" content="Vše o Zubíkovi, projekty, kontakt...">
    <link rel="icon" type="image/x-icon" href="./assets/Icon.ico">
    <link rel="apple-touch-icon" href="./assets/Icon.png">
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <script src="scripts.js"></script>
    <div class="Toplogo">

        <video autoplay loop muted plays-inline class="back-video">
            <source src="./assets/BackgV1D.mp4" type="video/mp4">
        </video>
        <!--poznamka-->
        <nav id="nav" class="desktop">
        <ul>
                <li><a href="index.php">Domů</a></li>
                <li><a href="index.php#read">O mně</a></li>
                <li><a href="index.php#github">GitHub</a></li>
                <li><a href="3Dmodels.php">3D modely</a></li>
                <li><a href="games.php">Hry</a></li>
                <li><a href="YouTube.php">YouTube</a></li>
                <li><a href="MyPC.php">Můj PC</a></li>
            </ul>
            <img class="IconDesktop" src="./assets/Icon.ico" alt="Icon">
        </nav>
        <nav class="mobile" role="navigation">
            <div id="mobilehamburger">
                <input type="checkbox" />
                <span></span>
                <span></span>
                <span></span>
                <ul id="menu">
                  <a href="index.php"><li>Domů</li></a>
                  <a href="index.php#read"><li>O mně</li></a>
                  <a href="index.php#github"><li>GitHub</li></a>
                  <a href="3Dmodels.php"><li>3D modely</li></a>
                  <a href="games.php"><li>Hry</li></a>
                  <a href="YouTube.php"><li>YouTube</li></a>
                  <a href="MyPC.php"><li>Můj PC</li></a>
                </ul>
              </div>
              <img class="Icon" src="./assets/Icon.ico" alt="Icon">
        </nav>
        <div class="content">
            <h1 style="font-size:10vw" >Galerie modelů</h1>
            <a href="#read">Číst</a>
        </div>
        <br>
        <div class="overlay">
            <br id="read">
            <br>
            <div class="article">
                <div class="text">
                    <h3>Zde si můžeš prohlédnout veškeré mnou vytvořené modely.</h3>
                    <h3>A <a href="https://github.com/Zubik1000CZ/3D-models" target="_blank" class="link">zde</a> si je můžeš stáhnout a použít ve vlastních projektech.</h3>
                </div>
            </div>
            
            <h1>Objekt 780</h1>
            <div class="articleModel"> 
                <div class="text">
                    <div class="popisekModel">
                    Přidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2022-07-18";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br><br>
                    
                        <h3>Model nikdy neexistujícího stroje. Existuje pouze ve hře World of Tanks.</h3><br>
                        <h3>Ke stažení <a href="https://sketchfab.com/3d-models/object-780-8c38f3e3ad8f4e80bf655e27133e150e" target="_blank" class="link">zde</a></h3><br>
                    </div>
                    <div class="Models"> 
                        <iframe title="kart" frameborder="2" allowfullscreen mozallowfullscreen="true"
                        webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking"
                        xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share width="100%" height="400vw"
                        src="https://sketchfab.com/models/8c38f3e3ad8f4e80bf655e27133e150e/embed" > </iframe>
                    </div>
                </div>
            </div>

            <h1>Kart</h1>
            <div class="articleModel"> 
                <div class="text">
                    <div class="popisekModel">
                    Přidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2022-06-1";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br><br>
                    
                        <h3>Mnou navržené vozidlo pro jízdu na Marsu xD.</h3>
                        <h3>Vyvinuto roku 2022 Inženýrem Zubíkem.</h3><br><br>
                        <h3>Ke stažení <a href="https://sketchfab.com/3d-models/t-27a1-cb8b30e0f82f4d42b200757eab36daa2" target="_blank" class="link">zde</a></h3><br>
                    </div>
                    <div class="Models"> 
                        <iframe title="kart" frameborder="2" allowfullscreen mozallowfullscreen="true"
                        webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking"
                        xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share width="100%" height="400vw"
                        src="https://sketchfab.com/models/a36ef8a835be4f1fb2e07b3f251a84aa/embed" > </iframe>
                    </div>
                </div>
            </div>
            
            <h1>T-27A1</h1>
            <div class="articleModel"> 
                <div class="text">
                    <div class="popisekModel">
                    Přidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2022-07-4";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br><br>
                    
                        <h3>Mnou navržený model středního tanku.</h3>
                        <h3>Model je k dispozici pouze za peníze. Můžete jej použít ve vlastních projektech, ale pod podmínkou, že mě zmíníte jako autora modelu.</h3>
                        <br>
                        <h3>Ke koupi <a href="https://github.com/Zubik1000CZ/3D-models/blob/main/maus.fbx" target="_blank" class="link">zde</a></h3><br>
                    </div>
                    <div class="Models">
                         <iframe  title="Maus" frameborder="0" allowfullscreen mozallowfullscreen="true"
                         webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking"
                          xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share width="100%" height="400vw"
                          src="https://sketchfab.com/models/cb8b30e0f82f4d42b200757eab36daa2/embed"> </iframe>
                    </div>
                </div>
            </div>

            <h1>Maus</h1>
            <div class="articleModel"> 
                <div class="text">
                    <div class="popisekModel">
                    Přidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2022-06-10";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br><br>
                    
                        <h3>Nejtěžší tank, který kdy spatřil světlo světa.</h3>
                        <h3>Vyvinuto v závěru 2. světové války. Ferdinand Porsche navrhl toto vozidlo na žádost samotného Adolfa Hitlera.</h3><br>
                        <h3>Vozidlo vážilo celých 188 tun a nebylo tudíž možné s tímto vozidlem přejet mosty.</h3>
                        <h3>Bylo proto navrženo tak, že jeden tank bude na břehu řeky a bude napájet druhý tank jej napájel. Poté se prohodily.</h3><br>
                        <h3>Samotné ovládání stroje byla noční můra. Hlavně pro střelce, který měl v případě poškození mechanizmu otáčet s asi 60ti tunovou věží otáčet ručně.</h3><br>
                        <h3>Ke stažení <a href="https://github.com/Zubik1000CZ/3D-models/blob/main/maus.fbx" target="_blank" class="link">zde</a></h3><br>
                    </div>
                    <div class="Models">
                         <iframe  title="Maus" frameborder="0" allowfullscreen mozallowfullscreen="true"
                         webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking"
                          xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share width="100%" height="400vw"
                          src="https://sketchfab.com/models/250a740271f9423d96f46e10f260baf5/embed"> </iframe>
                    </div>
                </div>
            </div>

            <h1>E-100</h1>
            <div class="articleModel"> 
                <div class="text">
                    <div class="popisekModel">
                    Přidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2022-06-17";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br><br>
                    
                        <h3>Prototyp supertěžkého tanku vyvýjený v Německu.</h3>
                        <h3>Tank měl sloužit jako odlehčená varianta tanku Maus a měl nést 150mm houfnici.</h3><br>
                       <h3>Tank nebyl nikdy postaven.</h3><br>
                        <h3>Ke stažení <a href="https://github.com/Zubik1000CZ/3D-models/blob/main/E-100%20150.fbx" target="_blank" class="link">zde</a></h3><br>
                    </div>
                    <div class="Models">
                        <iframe title="E-100 150" frameborder="0" allowfullscreen mozallowfullscreen="true"
                         webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking"
                          xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share  width="100%" height="400vw"
                          src="https://sketchfab.com/models/4ee9bfdc7b7d48219e3518aac9254576/embed"> </iframe>
                    </div>
                </div>
            </div>

            <h1>KPZ 20T</h1>
            <div class="articleModel"> 
                <div class="text">
                    <div class="popisekModel">
                    Přidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2022-06-12";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br><br>

                        <h3>Model nikdy neexistujícího tanku.</h3>
                        <h3>Tento model je výplodem mé fantazie.</h3><br><br>
                        <h3>Ke stažení <a href="https://github.com/Zubik1000CZ/3D-models/blob/main/KPZ%2020T.fbx" target="_blank" class="link">zde</a></h3><br>
                    </div>
                    <div class="Models">
                        <iframe title="KPZ 20T" frameborder="0" allowfullscreen mozallowfullscreen="true" 
                        webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking"
                         xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share width="100%" height="400vw"
                         src="https://sketchfab.com/models/ba9de9ed00e24a9a9ee4932cb51340ca/embed"> </iframe>
                    </div>
                </div>
            </div>

            
            <h1>Kranvagn</h1>
            <div class="articleModel"> 
                <div class="text">
                    <div class="popisekModel">
                    Přidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2022-06-12";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br><br>
                        <h3>Model Švédského těžkého tanku.</h3><br><br>
                        <h3>Ke stažení <a href="https://github.com/Zubik1000CZ/3D-models/blob/main/kran.fbx" target="_blank" class="link">zde</a></h3><br>
                    </div>
                    <div class="Models">
                        <iframe title="Kranvagn" frameborder="0" allowfullscreen mozallowfullscreen="true"
                         webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking"
                          xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share width="100%" height="400vw"
                           src="https://sketchfab.com/models/17e511638a734f95a62cd88f164e3912/embed"> </iframe>
                    </div>
                </div>
            </div>

            <footer class="footer">
                <p id="left"> email: michalzoufaly14@gmail.com</p>
                <p id="center"> &copyZubik1000CZ   2022-<?php echo date("Y");?></p>
                <p id="right"> Discord: Zubik1000CZ#7909</p>
        </footer>
        </div>
    
    </div>

</body>
</html>