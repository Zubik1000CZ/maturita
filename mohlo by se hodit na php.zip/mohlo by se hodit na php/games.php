<!doctype html>
<html lang="cs">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zub Games</title>
    <meta name="description" content="Vše o Zubíkovi.">
    <meta property="og:title" content="O Zubíkovi">
    <meta property="og:type" content="web">
    <meta property="og:url" content="">
    <meta property="og:description" content="Vše o Zubíkovi, projekty, kontakt...">
    <link rel="icon" type="image/x-icon" href="./assets/Icon.ico">
    <link rel="apple-touch-icon" href="./assets/Icon.png">
    <link rel="stylesheet" href="styles.css">

</head>

<body>
    <script src="scripts.js"></script>
    <div class="Toplogo">

        <video autoplay loop muted plays-inline class="back-video">
            <source src="./assets/BackgV1D.mp4" type="video/mp4">
        </video>
        <!--poznamka-->
        <nav id="nav" class="desktop">
        <ul>
                <li><a href="index.php">Domů</a></li>
                <li><a href="index.php#read">O mně</a></li>
                <li><a href="index.php#github">GitHub</a></li>
                <li><a href="3Dmodels.php">3D modely</a></li>
                <li><a href="games.php">Hry</a></li>
                <li><a href="YouTube.php">YouTube</a></li>
                <li><a href="MyPC.php">Můj PC</a></li>
            </ul>
            <img class="IconDesktop" src="./assets/Icon.ico" alt="Icon">
        </nav>
        <nav class="mobile" role="navigation">
            <div id="mobilehamburger">
                <input type="checkbox" />
                <span></span>
                <span></span>
                <span></span>
                <ul id="menu">
                  <a href="index.php"><li>Domů</li></a>
                  <a href="index.php#read"><li>O mně</li></a>
                  <a href="index.php#github"><li>GitHub</li></a>
                  <a href="3Dmodels.php"><li>3D modely</li></a>
                  <a href="games.php"><li>Hry</li></a>
                  <a href="YouTube.php"><li>YouTube</li></a>
                  <a href="MyPC.php"><li>Můj PC</li></a>
                </ul>
              </div>
              <img class="Icon" src="./assets/Icon.ico" alt="Icon">
        </nav>
        <div class="content">
            <h1 style="font-size:10vw" >Zubovy hry</h1>
            <a href="#read">Číst</a>
        </div>
        <br>
        <div class="overlay">
            <br id="read">
            <br>
            <div class="article">
                <div class="text">
                    <h3>Zde si můžeš prohlédnout veškeré mnou vytvořené hry, které vytvářím v <a href="https://unity.com/" target="_blank" class="link">Unity enginu</a>.</h3>
                    <h3><a href="https://github.com/Zubik1000CZ/Unity-by-Zubik1000CZ" target="_blank" class="link">Zde</a> si je můžeš stáhnout a zahrát.</h3>
                    <h3>Dočteš se tu základní informace o jednotivých titulech.</h3>
                    <h3>Doporučím ti nehledat smysl ve hrách, pokud ti nedávají smysl kekw.</h3>
                    <h3>A platí tu takové pravidlo. Co nefunguje, to není chyba, ale funkce :D, abys věděl.</h3>
                </div>
            </div>

            <h1>Find someone who asked</h1>
            <div class="articleGame"> 
                <div class="text">
                Přidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2023-01-13";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br><br>
                    
                    <div class="popisek">
                        <h3>Hra bez vyššího smyslu, jež je založena na jednom internetovém memu <a href="https://www.google.com/search?q=who+asked&sxsrf=ALiCzsaVJCKip7zPW3z3CRk8PK8MOhKogQ:1654112712607&source=lnms&tbm=isch&sa=X&ved=2ahUKEwjm45yFgo34AhUZG-wKHV4SCqUQ_AUoAXoECAIQAw&biw=1920&bih=977&dpr=1" target="_blank" class="link">Who asked</a> (česky: Kdo se ptal).</h3>
                        <h3>Cílem hry je, jak název napovídá, najít toho, kdo se ptal xD.</h3>
                        <h3>Tato "hra" je ke stažení <a href="https://github.com/Zubik1000CZ/Unity-by-Zubik1000CZ/blob/main/Find%20someone%20who%20asked.rar" target="_blank" class="link">zde</a>.</h3>
                    </div>
                    <img class="GamePicture" src="./assets/pictures/WhoAskedFHD.png" alt="WhoAsked">
                </div>
            </div>

            <h1>Tank Game</h1>
            <div class="articleGame"> 
                <div class="text">
                Přidáno před <?php
                        $dnes = date('Y-m-d');
                        $nahrano = "2023-01-13";
                        $rozdil = strtotime($nahrano) - strtotime($dnes);
                        $days = abs($rozdil/(60 * 60)/24);
                        echo(round($days,0));
                    ?> dny.<br><br>
                    
                    <div class="popisek">
                        <h3>Tato hra je momentálně ve vývoji. Název hry zatím dočasný. Bližší informace někdy v budoucnu.</h3>
                    </div>
                    <img class="GamePicture" src="./assets/pictures/TankGame.png" alt="TankGame">
                </div>
            </div>

            
            <footer class="footer">
                <p id="left"> email: michalzoufaly14@gmail.com</p>
                <p id="center"> &copyZubik1000CZ   2022-<?php echo date("Y");?></p>
                <p id="right"> Discord: Zubik1000CZ#7909</p>
        </footer>
        </div>
    </div>
</body>
</html>