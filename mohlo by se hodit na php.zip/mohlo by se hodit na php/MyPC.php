<!doctype html>
<html lang="cs">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Můj PC</title>
    <meta name="description" content="Vše o Zubíkovi.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <meta property="og:title" content="O Zubíkovi">
    <meta property="og:type" content="web">
    <meta property="og:url" content="">
    <meta property="og:description" content="Vše o Zubíkovi, projekty, kontakt...">
    <link rel="icon" type="image/x-icon" href="./assets/Icon.ico">
    <link rel="apple-touch-icon" href="./assets/Icon.png">
    <link rel="stylesheet" href="styles.css">

</head>

<body>
    <script src="scripts.js"></script>
    <div class="Toplogo">

        <video autoplay loop muted plays-inline class="back-video">
            <source src="./assets/BackgV1D.mp4" type="video/mp4">
        </video>
        <!--poznamka-->
        <nav id="nav" class="desktop">
        <ul>
                <li><a href="index.php">Domů</a></li>
                <li><a href="index.php#read">O mně</a></li>
                <li><a href="index.php#github">GitHub</a></li>
                <li><a href="3Dmodels.php">3D modely</a></li>
                <li><a href="games.php">Hry</a></li>
                <li><a href="YouTube.php">YouTube</a></li>
                <li><a href="MyPC.php">Můj PC</a></li>
            </ul>
            <img class="IconDesktop" src="./assets/Icon.ico" alt="Icon">
        </nav>
        <nav class="mobile" role="navigation">
            <div id="mobilehamburger">
                <input type="checkbox" />
                <span></span>
                <span></span>
                <span></span>
                <ul id="menu">
                  <a href="index.php"><li>Domů</li></a>
                  <a href="index.php#read"><li>O mně</li></a>
                  <a href="index.php#github"><li>GitHub</li></a>
                  <a href="3Dmodels.php"><li>3D modely</li></a>
                  <a href="games.php"><li>Hry</li></a>
                  <a href="YouTube.php"><li>YouTube</li></a>
                  <a href="MyPC.php"><li>Můj PC</li></a>
                </ul>
              </div>
              <img class="Icon" src="./assets/Icon.ico" alt="Icon">
        </nav>
        <div class="content">
            <h1 style="font-size:10vw" >Můj PC</h1>
            <a href="#read">Číst</a>
        </div>
        <br>
        <div class="overlay">
            <br id="read">
            <br>
            <div class="article">
                <div class="text">
                    <h3>Zde si můžeš prohlédnout, jaký používám PC k tvorbě obsahu, který můžete na mém webu najít.</h3>
                <h3>Používám Custom sestavu, počítač je tedy mnou sestavený. Výhodou je, že na rozdíl od Pre-buildu (již sestavený PC) je snáze rozšiřitelný.</h3>
                </div>
            </div>
            <br>
            <div class="article">
                <div class="text">
                    <h3>Pokud sami plánujete stavbu počítače, můžete se ozvat. Rád pomohu s výběrem komponent :).</h3>
                </div>
            </div>

        <div class="seznamKomponent">   
            <h1>Nová Sestava</h1>
            <div class="tabulka">
                
                <table class="table">
                    <tr>
                        <th><div class="tableText">Typ</div></th>
                        <th><div class="tableText">Komponenta</div></th>
                    </tr>
                    <tr>
                        <td><div class="tableText">Procesor</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/amd-ryzen-5-7600-d7612605.htm" target="_blank" class="link">AMD Ryzen 5 7600</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Grafická karta</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/asus-dual-gtx1060-o3g-d4422601.htm" target="_blank" class="link">GTX 1060 3GB ASUS DUAL</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Základní deska</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/gigabyte-b650m-ds3h-d7458407.htm" target="_blank" class="link">GIGABYTE B650M DS3H</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">RAM</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/gaming/kingston-fury-16gb-kit-ddr5-6000mhz-cl40-beast-black-d7004725.htm" target="_blank" class="link">Kingston FURY 16GB DDR5</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">SSD</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/kingston-kc3000-nvme-1tb-d6817197.htm" target="_blank" class="link">Kingston KC3000 NVMe 1TB</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Druhé SSD</div></td>
                        <td><div class="tableText"><a href="https://www.czc.cz/apacer-as350-panther-2-5-240gb/248407/produkt" target="_blank" class="link">Apacer AS350 PANTHER, 240GB</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">HDD</div></td>
                        <td><div class="tableText">nějaké random 500GB</div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">CPU chladič</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/silentiumpc-spartan-4-d5858916.htm" target="_blank" class="link">SilentiumPC Spartan 4</a></div></td>

                    </tr>
                    <tr>
                        <td><div class="tableText">Zdroj</div></td>
                        <td><div class="tableText">600W no name</div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Skříň</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/msi-mag-vampiric-011c-amd-edition-d5714528.htm" target="_blank" class="link">MSI MAG VAMPIRIC 011C</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Primární monitor</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/23-8-hp-24f-d5321372.htm" target="_blank" class="link">23.8" HP 24f</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Sekundární monitor</div></td>
                        <td><div class="tableText">Nějaký random 16:9</div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Myš</div></td>
                        <td><div class="tableText"><a href="https://www.asus.com/cz/accessories/mice-and-mouse-pads/tuf-gaming/tuf-gaming-m5/" target="_blank" class="link">Asus Tuf Gaming M5</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Headset</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/spc-gear-viro-gaming-headset-d6158487.htm" target="_blank" class="link">SPC Gear Viro Gaming</a></div></td>

                    </tr>
                    <tr>
                        <td><div class="tableText">klávesnice</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/hyperx-alloy-origins-pbt-red-us-d7332624.htm" target="_blank" class="link">HyperX Alloy Origins PBT Red</a></div></td>
                    </tr>
                </table>
            </div>
            <img class="sestavaPic" src="./assets/pictures/PC.png" alt="PC">
        </div>
        
        <div class="seznamKomponent">
            <h1>Old Sestava</h1>
            <div class="tabulka">
                <table class="table">
                    <tr>
                        <th><div class="tableText">Typ</div></th>
                        <th><div class="tableText">Komponenta</div></th>
                    </tr>
                    <tr>
                        <td><div class="tableText">Procesor</div></td>
                        <td><div class="tableText"><a href="https://www.czc.cz/intel-core-i3-4150/152565/produkt" target="_blank" class="link">Intel Core i3-4150</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Grafická karta</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/asus-dual-gtx1060-o3g-d4422601.htm" target="_blank" class="link">GTX 1060 3GB ASUS DUAL</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Základní deska</div></td>
                        <td><div class="tableText">nějaký šrot pro i3 4. gen</div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">RAM</div></td>
                        <td><div class="tableText">4GB DDR3 (další 4GB nefunkční)</div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">SSD</div></td>
                        <td><div class="tableText"><a href="https://www.czc.cz/apacer-as350-panther-2-5-240gb/248407/produkt" target="_blank" class="link">Apacer AS350 PANTHER, 240GB</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">HDD</div></td>
                        <td><div class="tableText">nějaké random 500GB</div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">CPU chladič</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/silentiumpc-spartan-4-d5858916.htm" target="_blank" class="link">SilentiumPC Spartan 4</a></div></td>

                    </tr>
                    <tr>
                        <td><div class="tableText">Zdroj</div></td>
                        <td><div class="tableText">600W no name</div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Skříň</div></td>
                        <td><div class="tableText">Kus náhodného plechu</div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Primární monitor</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/23-8-hp-24f-d5321372.htm" target="_blank" class="link">23.8" HP 24f</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Sekundární monitor</div></td>
                        <td><div class="tableText">Nějaký random 5:4</div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Myš</div></td>
                        <td><div class="tableText"><a href="https://www.yenkee.cz/herni-mys-ambush/yms-3017" target="_blank" class="link">Yenkee Ambush YMS 3017</a></div></td>
                    </tr>
                    <tr>
                        <td><div class="tableText">Headset</div></td>
                        <td><div class="tableText"><a href="https://www.alza.cz/spc-gear-viro-gaming-headset-d6158487.htm" target="_blank" class="link">SPC Gear Viro Gaming</a></div></td>

                    </tr>
                    <tr>
                        <td><div class="tableText">klávesnice</div></td>
                        <td><div class="tableText">Nějaká PS/2 z popelnice</div></td>
                    </tr>
                </table>
            </div>
        </div>

        <footer class="footer">
            <p id="left"> email: michalzoufaly14@gmail.com</p>
            <p id="center"> &copyZubik1000CZ   2022-<?php echo date("Y");?></p>
            <p id="right"> Discord: Zubik1000CZ#7909</p>
    </footer>
        </div>
    </div>
</body>
</html>