let btSlova=[];
function priprav(){
    let words = document.getElementById("vstup").value.split(" ");
    words.forEach(sl => {
        var tl = document.createElement("button");
        tl.innerHTML=sl;
        tl.addEventListener("click",()=>{nastav(tl)});
        btSlova.push(tl);
        document.getElementById("slova").appendChild(tl);
    });
    document.getElementById("zadani").style.display = "none";
    document.getElementById("pjTab").style.display = "";
}
const selecty=[
    "<select onchange=\"vzor(this);\"><option value=\"3\">mužský</option><option value=\"4\">ženský</option><option value=\"5\">střední</option></select>",
    "<select><option>jednotné</option><option>množné</option></select>",
    "<select><option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option><option>7</option></select>",
    "<select><option>pán</option><option>hrad</option><option>muž</option><option>stroj</option><option>předseda</option><option>soudce</option></select>",
    "<select><option>žena</option><option>růže</option><option>píseň</option><option>kost</option></select>",
    "<select><option>město</option><option>moře</option><option>kuře</option><option>stavení</option></select>"
];
function vzor(sender) {
    sender.parentElement.parentElement.lastChild.innerHTML=selecty[sender.value];
}
function nastav(sender) {
    sender.style.backgroundColor = vybBarva;
    if(vyb=="i1")//je podstatné jméno
    {
        var tab = document.getElementById("pjTab");
        var r = document.createElement("tr");
        tab.appendChild(r);
        for(var i = 0; i < 5; i++)
        {
            var s = document.createElement("td");
            if(i==0)
            {
                s.innerHTML = sender.innerHTML;
            }
            else
            {
                s.innerHTML=selecty[i-1];
            }
            r.appendChild(s);
        }
    }
}
let vyb = "i1";
let vybBarva=document.getElementById(vyb).style.backgroundColor;
function vyber(id) {
    document.getElementById(vyb).className = "";
    document.getElementById(id).className = "vybrano";
    vyb = id;
    vybBarva = document.getElementById(vyb).style.backgroundColor;
}
let reseni=[];
function zadej(){
    document.getElementById("zadani").style.display = "none";
    document.getElementById("tl1").style.display = "none";
    document.getElementById("tl2").style.display = "";
    vyber("i1");
    btSlova.forEach(bt => {
        reseni.push(bt.style.backgroundColor);
        bt.style.backgroundColor = "white";
    });
}
function odevzdej() {
    var spravne = 0;
    var spatne = 0;
    for (let i = 0; i < btSlova.length; i++) {
        if(btSlova[i].style.backgroundColor == reseni[i]){
            spravne++;
        }        
        else{
            spatne++;
        }
    }
    document.getElementById("vysledek").innerHTML="Správně: "+spravne+", špatně: "+spatne;
}