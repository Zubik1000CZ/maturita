<!DOCTYPE html>
<html lang="cz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>AdamPhP</title>
</head>
<body>
    <form method="GET">
    Matika: <input type="number" name="m"><br>
    Čeština: <input type="number" name="c"><br>
    Databáze: <input type="number" name="d"><br>
    Informatika: <input type="number" name="i"><br>
    Tělák: <input type="number" name="t"><br>
    Absence: <input type="number" name="a"><br>
    Jmeno: <input type="text" name="j"><br>
    <input type="submit" name="vypocet" value="Vypočítej">
    </form>
    <?php
    $servername = "localhost";
    $username = "19ib31";
    $password = "72497994";
    $database = "19ib31";
    $conn = mysqli_connect($servername, $username, $password, $database);


    $m = $_GET['m'];
    $c = $_GET['c'];
    $d = $_GET['d'];
    $i = $_GET['i'];
    $t = $_GET['t'];
    $a = $_GET['a'];
    $j = $_GET['j'];
    $vypocet = $_GET['vypocet'];


    if($m>=5 || $c>=5 || $d>=5 || $i>=5 || $t>=5 || $a>=5)
    {
        $iq = ($m + $c +$d + $i + $t) / 5;
        //$iq = rand(0,50);
        echo($j."ovo IQ je kolem: ".$iq);
        /*$sql="CREATE TABLE AdamTab (
            id INT(5) AUTO_INCREMENT PRIMARY KEY,
            IQ INT(3) NOT NULL
            )";
        mysqli_query($conn,$sql);*/

        $sql="ALTER TABLE AdamTab ADD jmeno varchar(10)";
            mysqli_query($conn, $sql);


       /* $sql="UPDATE AdamTab SET IQ='$iq' WHERE id=1";
        mysqli_query($conn, $sql);*/
    }
    $sql="UPDATE AdamTab SET jmeno='$j' WHERE id=1";
    mysqli_query($conn, $sql);
    $sql="SELECT IQ FROM AdamTab WHERE id=1";
                        $result=mysqli_query($conn,$sql);
                        $hodnota=mysqli_fetch_assoc($result);
                        $iq = $hodnota["IQ"]*2;
    echo ('<br>'.$j."ovo IQ: ".$iq);
    ?>


    </form>
</body>
</html>