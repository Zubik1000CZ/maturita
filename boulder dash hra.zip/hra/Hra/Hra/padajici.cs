﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Hra
{
    internal class padajici : pohyblivy
    {
        public padajici(int x, int y, ImageBrush vypln) : base(x, y, vypln)
        {
        }

        public override void krok(int i, int j)
        {
            p.Margin=new System.Windows.Thickness(j*50, i+1*50,0,0);
        }
    }
}
