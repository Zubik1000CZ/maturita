﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows;

namespace Hra
{
    internal class hrac : pohyblivy
    {
        

        public hrac(int x, int y) : base(x, y, info.hrac)
        {

        }


        public override void krok(int x, int y)
        {
            if (mapa.muzuVstoupit(poziceX + x, poziceY + y))
            {
                
                p.Margin = new Thickness(p.Margin.Left + x*50, p.Margin.Top + y*50, 0, 0);
            }

        }

    }
}
