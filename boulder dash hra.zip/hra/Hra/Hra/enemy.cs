﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Hra
{
    internal class enemy : pohyblivy
    {
        public enemy(int x, int y) : base(x, y,info.enemy)
        {
        }

        public override void krok(int x, int y)
        {
            throw new NotImplementedException();
        }
    }
}
