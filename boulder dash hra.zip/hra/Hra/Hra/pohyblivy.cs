﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls.Ribbon.Primitives;
using System.Windows.Media;

namespace Hra
{
    abstract internal class pohyblivy : policko
    {
        protected pohyblivy(int x, int y, ImageBrush vypln) : base(x, y, vypln)
        {

        }

        abstract public void krok(int x, int y);
    }
}