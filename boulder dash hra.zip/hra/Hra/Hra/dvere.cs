﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Hra
{
    internal class dvere : policko
    {
        public dvere(int x, int y) : base(x, y, info.dvere)
        {
        }
    }
}
