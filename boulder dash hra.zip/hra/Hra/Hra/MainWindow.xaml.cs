﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Hra
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            info.plocha = grid;
            StreamReader sr = new StreamReader(@"../../../Levels/level1.txt");
            policko pol=null;
            int x = 0;
            int y = 0;
            mapa.map = new List<policko[]>();
            while(!sr.EndOfStream)
            { 
                string s = sr.ReadLine();
                mapa.map.Add(new policko[s.Length]);
                foreach (char z in s)// pro každý znak v řádku
                {
                    switch (z)
                    {
                        case '0':
                            pol = new zed(x,y);
                            break;
                        case '1':;
                            h = new hrac(x, y);
                            break;
                        case '2':
                            pol = new enemy(x, y);
                            break;
                        case '3':
                            pol = new kamen(x, y);
                            break;
                        case '4':
                            pol = new diamant(x, y);
                            break;
                        case '5':
                            pol = new hlina(x,y);
                            break;
                        case '6':
                            pol = new dvere(x, y);
                            break;
                    }
                    if (z != '1')
                    {
                        mapa.map[y/50][x/50]=pol;
                    }
                   
                    x += 50;
                }
                y += 50;
                x = 0;
            }
            sr.Close();
            cas.Interval = new TimeSpan(0, 0, 0, 0, 100);
            cas.Tick += Cas_Tick;
            cas.Start();
        }
        hrac h;
        private void Cas_Tick(object? sender, EventArgs e)
        {
            h.krok(x, y);
            for (int i =  mapa.map.Count-1;i >=0; i--)
            {
                for (int j = 0; j < mapa.map[i].Length; j++)
                {
                    if(!mapa.jePrazdne(j,i) && mapa.jePadajici(i,j))
                    {
                        if (mapa.jePrazdne(j, i + 1))
                        {
                            mapa.Spadni(i, j);
                        }
                    }
                }
            }
        }
        int x = 0, y = 0;
        DispatcherTimer cas = new DispatcherTimer();
        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            switch(e.Key)
            {
                case Key.Up:
                    x = 0;
                    y = -1;
                    break;
                case Key.Down:
                    x = 0;
                    y = 1;
                    break;
                case Key.Left:
                    x = -1;
                    y = 0;
                    break;
                case Key.Right:
                    x = 1;
                    y = 0;
                    break;
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.Up:
                case Key.Down:
                case Key.Left:
                case Key.Right:
                    x = 0;
                    y = 0;
                    break;
            }
        }
    }
}