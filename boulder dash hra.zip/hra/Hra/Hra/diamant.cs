﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hra
{
    internal class diamant : padajici
    {
        public diamant(int x, int y) : base(x, y, info.diamant)
        {
        }
    }
}
