﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hra
{
    internal class mapa
    {
        static public List<policko[]> map{ get; set; }

        internal static bool muzuVstoupit(int x, int y)
        {
            if (jePrazdne(x, y))
            {
                return true;
            }
            if (map[y][x].GetType() == typeof(kamen) || map[y][x].GetType() == typeof(zed))
            {
                return false;
            }
            else if (jeHlina(x, y))
            {
                map[y][x].Zmiz();
                map[y][x] = null;
            }
            return true;
        }

        public static bool jePrazdne(int x, int y)
        {
            return map[y][x] == null;
        }

        internal static bool jeHlina(int x, int y)
        {
            return map[y][x].GetType() == typeof(hlina);
        }

        internal static bool jePadajici(int i, int j)
        {
            return map[i][j].GetType().BaseType == typeof(padajici);
        }


        internal static void Spadni(int i, int j)
        {
            (map[i][j] as padajici).krok(i,j);
            map[i + 1][j] = map[i][j];
            map[i][j]=null;
        }
    }
}