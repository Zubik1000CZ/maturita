﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Hra
{
    abstract internal class policko
    {
        protected Rectangle p;
        protected int poziceX
        {
            get
            {
                return (int)(p.Margin.Left / 50);
            }
        }
        protected int poziceY
        {
            get
            {
                return (int)(p.Margin.Top / 50);
            }
        }




        protected policko(int x,int y,ImageBrush vypln)
        {
            p = new Rectangle()
            {
                Width = 50,
                Height = 50,
                VerticalAlignment = VerticalAlignment.Top,
                HorizontalAlignment = HorizontalAlignment.Left,
                Fill = vypln,
                Margin = new Thickness(x, y, 0,0)
            };
            info.plocha.Children.Add(p);
        }

        internal void Zmiz()
        {
            info.plocha.Children.Remove(p);
        }
    }
}
