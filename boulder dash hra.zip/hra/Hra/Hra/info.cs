﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Media;

namespace Hra
{
    static internal class info
    {
        public static Grid plocha { get; set; }
        public static ImageBrush kamen { get; } = new ImageBrush(new BitmapImage(new Uri(@"../../../Images/kamen.png", UriKind.Relative)));
        public static ImageBrush hlina { get; } = new ImageBrush(new BitmapImage(new Uri(@"../../../Images/hlina.png", UriKind.Relative)));
        public static ImageBrush zed { get; } = new ImageBrush(new BitmapImage(new Uri(@"../../../Images/zed.png", UriKind.Relative)));
        public static ImageBrush hrac { get; } = new ImageBrush(new BitmapImage(new Uri(@"../../../Images/hrac.png", UriKind.Relative)));
        public static ImageBrush enemy { get; } = new ImageBrush(new BitmapImage(new Uri(@"../../../Images/enemy.png", UriKind.Relative)));
        public static ImageBrush diamant { get; } = new ImageBrush(new BitmapImage(new Uri(@"../../../Images/diamant.png", UriKind.Relative)));
        public static ImageBrush dvere { get; } = new ImageBrush(new BitmapImage(new Uri(@"../../../Images/dvere.png", UriKind.Relative)));

    }
}
